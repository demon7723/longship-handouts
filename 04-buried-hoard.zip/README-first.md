# The Buried Hoard — recovered repository
You hold a recovered clone of Saltvik's longship-fleet **deploy-tooling** repo
(`saltvik-hoard/`, a full git repository — `.git` and all). The keeper swears every secret was
scrubbed before it left the hall. The keeper is wrong. Dig.
Tip: this is about *history*, not the current files. `git log`, `git branch -a`, `git reflog`.
