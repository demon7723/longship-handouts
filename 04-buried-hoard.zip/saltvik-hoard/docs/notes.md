The Thing approved the vault migration. See runbook.
