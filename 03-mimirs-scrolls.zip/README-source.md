# Mimir's Scroll-Hall — source under review

The Saltvik ledger portal, a TRAINING build. It runs entirely in your browser — open
`index.html` (no server). Your task is white-box: **read the source**, find what it does
wrong, and make the hall give up three secrets it should not.
