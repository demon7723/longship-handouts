#!/usr/bin/env python3
# Saltvik SP - offline assertion checker.  Usage: python3 sp_verify.py <assertion.xml> [--sp ledger|treasury]
# (Simplified model of a SAML SP. It has real-world flaws. Read the code.)
import sys, xml.etree.ElementTree as ET
KEY=b"yggdrasil"
KNOWN_SIGS={"c2lnbmVkLWJ5LWlkcC1sb2tp-ORIG-9f1c7a"}            # the SP only recognises the genuinely-issued signature
G2=[55, 34, 28, 5, 28, 62, 6, 7, 31, 16, 0, 9, 1, 22, 62, 18, 26, 31, 28, 21, 19, 13, 29, 15, 44, 26, 4, 22, 18, 11, 0, 45, 15, 22, 31, 9, 11, 56, 5, 1, 45, 21, 1, 28, 31, 13, 2, 3, 25]; G3=[55, 34, 28, 19, 0, 0, 3, 54, 24, 17, 2, 56, 23, 27, 6, 29, 8, 24, 12, 21, 2, 59, 19, 15, 23, 54, 31, 20, 18, 0, 3, 30, 4, 44, 8, 51, 10, 2, 4, 11, 28, 5, 44, 15, 13, 26, 2, 26]; G4=[55, 34, 28, 10, 29, 62, 18, 28, 8, 16, 2, 9, 7, 23, 62, 16, 1, 9, 26, 12, 56, 9, 23, 0, 29, 26, 51, 11, 2, 23, 8, 19, 24, 44, 8, 2, 0, 16, 15, 1, 0, 4, 14]
def dec(a): return bytes(a[i]^KEY[i%len(KEY)] for i in range(len(a))).decode()
args=[a for a in sys.argv[1:] if not a.startswith("--")]
sp="ledger"
if "--sp" in sys.argv: sp=sys.argv[sys.argv.index("--sp")+1]
root=ET.parse(args[0]).getroot()
assertions=root.findall(".//Assertion")
sigs=[s.text for s in root.findall(".//SignatureValue")]
# FLAW A: if the assertion carries no signature at all, accept it anyway ("legacy IdP")
accepted = any(s in KNOWN_SIGS for s in sigs) or len(sigs)==0
if not accepted:
    sys.exit("REJECTED: signature present but not recognised.")
# FLAW B: role is read from the LAST assertion, while the signature need only exist SOMEWHERE
role=None
for a in assertions:
    for at in a.findall(".//Attribute"):
        if at.get("Name")=="role": role=at.text
# FLAW C: the <Audience> is never compared against sp
print(f"[sp={sp}] accepted assertion; effective role = {role}")
if role=="crew": print("Welcome to the ledger-hall, crew. (nothing secret here)")
elif role=="jarl": print("JARL ACCESS:", dec(G2))
elif role=="org-admin" and sp=="ledger": print("ORG-ADMIN ACCESS:", dec(G3))
elif role=="org-admin" and sp=="treasury": print("TREASURY (replayed):", dec(G4))
else: print("No grant for that role here.")
