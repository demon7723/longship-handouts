ls -la
cd /opt/backup
# testing the nightly job
mysql -u root -p'Thrall#Winter24' -e 'show databases;'
export LEDGER_DBPASS=Thrall#Winter24
clear
sudo -l
