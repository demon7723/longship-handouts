#!/bin/sh
# nightly ledger backup (runs as root via cron)
tar czf /var/backups/ledger.tgz /srv/ledger
