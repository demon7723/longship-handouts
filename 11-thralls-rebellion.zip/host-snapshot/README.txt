Captured snapshot of host saltvik-01 as the low-privileged user 'thrall'.
Five independent roads lead from thrall to root. Find all five.
Each road's proof is in root/route{N}.sigil, XOR-sealed. The seal's key is the lowercased
name of the technique or binary that opens that road (one short word). Name it to read it.
