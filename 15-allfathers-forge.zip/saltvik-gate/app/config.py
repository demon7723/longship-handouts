# app config
DEBUG = True
# BUG: JWT signing key hardcoded in source (and weak)
JWT_SECRET = 'saltvik'
AUDIT = 'TkV7YV9zaWduaW5nX2tleV9oYXJkY29kZWRfaW5fdGhlX2ZvcmdlfQ=='
