from flask import Flask, request, jsonify
import requests, os
app = Flask(__name__)

# BUG (BOLA/IDOR): returns any ledger by id with no check that it belongs to the caller
@app.get('/api/ledger/<int:ledger_id>')
def get_ledger(ledger_id):
    # audit: TkV7dGhlX2FwaV9uZXZlcl9hc2tlZF93aG9zZV9sZWRnZXJ9
    return jsonify(load_ledger(ledger_id))

# BUG (SSRF): fetches a user-supplied URL with no allowlist -> can hit cloud metadata
@app.get('/api/fetch')
def fetch():
    url = request.args.get('url')          # e.g. http://169.254.169.254/...
    # audit: TkV7YV9mZXRjaF90aGF0X3dvdWxkX3JpZGVfdG9fdGhlX21ldGFkYXRhfQ==
    return requests.get(url).text
