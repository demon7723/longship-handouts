sealed_gift.b64 is the chest. It is XOR-sealed with sha256(<the HS256 secret that signs token.jwt>).
Recover the secret from token.jwt using wordlist.txt, then base64-decode sealed_gift and XOR it with sha256(secret).
