# Incident bundle - host WS-07, 2024-08-30
Artifacts: email_gateway.csv, sysmon.jsonl, autoruns.txt,
capture.pcap, security.jsonl, disk_timeline.body, final.sigil. Reconstruct the kill chain, stage by stage.
